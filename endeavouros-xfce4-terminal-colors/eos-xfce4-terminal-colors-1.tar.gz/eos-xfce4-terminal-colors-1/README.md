# eos-xfce4-terminal-colors
EndeavourOS color scheme for xfce4-terminal
